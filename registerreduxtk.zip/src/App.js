import './App.css';
import Register from './component/register/register';


function App() {
  return (
    <div className="App">
     <Register />
    </div>
  );
}

export default App;
